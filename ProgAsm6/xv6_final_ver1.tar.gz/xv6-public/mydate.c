#include "types.h"
#include "user.h"
#include "date.h"

void curr_date_IST();
int leap_year_check(int year);

//Enum for Months of the Year
enum MONTH_YEAR
{
    JAN,
    FEB,
    MAR,
    APR,
    MAY,
    JUN,
    JUL,
    AUG,
    SEP,
    OCT,
    NOV,
    DEC
};

//Array type implementation for Month number and its corresponding month name
//0 indexed
static char(*month_name[]) = {
    [JAN] "January",
    [FEB] "February",
    [MAR] "March",
    [APR] "April",
    [MAY] "May",
    [JUN] "June",
    [JUL] "July",
    [AUG] "August",
    [SEP] "September",
    [OCT] "October",
    [NOV] "November",
    [DEC] "December",
};

int main(int argc, char *argv[])
{
    struct rtcdate r;
    if (mydate(&r))
    {
        printf(2, "date failed\n");
        exit();
    }
    else
    {
        /********************************
         * This section is for printing the current time in UTC
         */ 

        //printf(1, "Year: %d\nMonth: %d or %s\nDate: %d\nHour: %d\nMinute: %d\nSecond: %d\n", r.year, r.month, month_name[r.month - 1], r.day, r.hour, r.minute, r.second);

        /********************************/

        /********************************
         * This section is for printing the current time in IST
         */ 
        curr_date_IST();

        /********************************/
    }
    exit();
}

//Function to check if a year is leap year of not
int leap_year_check(int year)
{
    if (year % 400 == 0)
    {
        return 1;
    }
    else if (year % 100 == 0)
    {
        return 0;
    }
    else if (year % 4 == 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

//Function to print the current Date and time in IST format
void curr_date_IST()
{
    struct rtcdate r;
    if (mydate(&r))
    {
        printf(2, "date failed\n");
        exit();
    }
    //Adding 30 min first and check if it shifts to the next hour
    if (r.minute + 30 >= 60)
    {
        r.hour = r.hour + 1;
        r.minute = r.minute + 30 - 60;
    }
    else
    {
        r.minute = r.minute + 30;
    }

    //Add 5 hours and check if it shifts to the next day
    if (r.hour + 5 >= 24)
    {
        r.day = r.day + 1;
        r.hour = r.hour + 5 - 24;
    }
    else
    {
        r.hour = r.hour + 5;
    }

    //Case where the day shifts to the next day and it is 31st December, so we need to increment the year and reset the date back to 1st January
    if (r.day == 32 && r.month - 1 == DEC)
    {
        r.year = r.year + 1;
        r.day = 1;
        r.month = 1;
    }
    //Case where the day shifts to the next day and it is 31st of 31 days month, so we need to increment the month and reset the date back to 1st 
    if (r.day == 32 && (r.month - 1 == JAN || r.month - 1 == MAR || r.month - 1 == MAY || r.month - 1 == JUL || r.month - 1 == AUG || r.month - 1 == OCT))
    {
        r.day = 1;
        r.month = r.month + 1;
    }
    //Case where the day shifts to the next day and it is 30th of 30 days month, so we need to increment the month and reset the date back to 1st 
    if (r.day == 31 && (r.month - 1 == APR || r.month - 1 == JUN || r.month - 1 == SEP || r.month - 1 == NOV))
    {
        r.day = 1;
        r.month = r.month + 1;
    }
    //Case where it was 29th Feb in a leap year and it shifts to the next day
    if (r.day == 30 && r.month - 1 == FEB)
    {
        r.month = r.month + 1;
        r.day = 1;
    }
    //Case where it was 28th Feb and it is not a leap year then it shifts to the next day
    if (r.day == 29 && leap_year_check(r.year) == 0 && r.month - 1 == FEB)
    {
        r.month = r.month + 1;
        r.day = 1;
    }

    printf(1, "Year: %d\nMonth: %d or %s\nDate: %d\nHour: %d\nMinute: %d\nSecond: %d\n", r.year, r.month, month_name[r.month - 1], r.day, r.hour, r.minute, r.second);
}
