#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

// #include "pgtprint.c"

int sys_fork(void)
{
  return fork();
}

int sys_exit(void)
{
  exit();
  return 0; // not reached
}

int sys_wait(void)
{
  return wait();
}

int sys_kill(void)
{
  int pid;

  if (argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int sys_getpid(void)
{
  return myproc()->pid;
}

int sys_sbrk(void)
{
  int addr;
  int n;

  if (argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if (growproc(n) < 0)
    return -1;
  return addr;
}
/*
* Modified sbrk to handle the case where the process is trying to change proc->sz but returning original proc->sz
*
*/
// int sys_sbrk(void)
// {
//   int addr;
//   int n;

//   if (argint(0, &n) < 0)
//     return -1;
//   addr = myproc()->sz;
//   int tmp = addr + n;
//   myproc()->sz = tmp;
//   // if(n < 0)
//   // {
//   //   uvm_dealloc(myproc()->pgdir, addr, tmp);
//   // }
//   return addr;
// }

int sys_sleep(void)
{
  int n;
  uint ticks0;

  if (argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while (ticks - ticks0 < n)
  {
    if (myproc()->killed)
    {
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

//Added mydate system call
int sys_mydate()
{
  struct rtcdate *rt;
  if (argptr(0, (void *)&rt, sizeof(rt)) < 0)
  {
    return -1;
  }
  cmostime(rt);
  return 0;
}

//Added pgtprint system call
int sys_pgtprint()
{
  pde_t *pgdir = myproc()->pgdir;
  int entry_num = 0;
  for(int i = 0; i < NPDENTRIES; i++)
  {
    if(pgdir[i] & PTE_P)
    {
      // cprintf("%d: %x\n", i, pgdir[i]);
      pde_t *pde = (pde_t *)P2V(PTE_ADDR(pgdir[i]));
      for(int j = 0; j < NPTENTRIES; j++)
      {
        if((pde[j] & PTE_P) && (pde[j] & PTE_U))
        {
          // cprintf("Entry number: %d, Virtual address: %p, Physical address: %x\n", entry_num, P2V(&pde[j]), &(pde[j]));
          /*******
           * Uncomment this for part 1 of the assignment and comment for part 2 of the assignment
           */ 
          // cprintf("Entry number: %d, Virtual address: %p, Physical address: %x\n", entry_num, (&pde[j]), V2P(&pde[j]));

          /*******
           * Uncomment this for part 2 of the assignment and comment for part 1 of the assignment
           */
          cprintf("Pgdir number %d Entry number: %d, Virtual address: %p, Physical address: %p\n", i, entry_num, (&pde[j]), V2P(&pde[j]));
          entry_num++;
        }
      }
    }
  }
  // print_pagetable(pgdir);
  return 0;
}