#include "types.h"
#include "user.h"
#include "date.h"

#define N 100000
// #include "vm.c"
// #include "defs.h"

// int pgtprint_func(pde_t *pgdir, int num)
// {
//   for (int i = 0; i < 512; i++)
//   {
//     pte_t pde = pgdir[i];
//     if (pde & PTE_P)
//     {
//       //   printf("..");
//       // for(int j=0;j<num;j++) {
//       //   printf(" ..");
//       // }
//       printf("%d: pte %p pa %p\n", i, pde, PTE2PA(pde));
//       if ((pde & (PTE_P | PTE_W | PTE_U)) == 0)
//       {
//         // this PTE points to a lower-level page table.
//         pte_t child = PTE2PA(pde);
//         pgtprint_func((pte_t)child, num + 1);
//       }
//     }
//   }
//   return 0;
// }

// void print_pagetable(pde_t *pgdir)
// {
//   pgtprint_func(pgdir, 0);
// }

/*****************
 * To test for Global Array part for first part of the assignment uncomment this below part and comment the local variable part
 * Make sure to make the appropriate changes in exec.c to run part 1 without demandpaging
 */

// int arrGlobal[N];

/*******************
 * Global Part ends here
 */

int main(int argc, char *argv[])
{
    /*****************
     * To test for Global Array part for first part of the assignment uncomment this below part and comment the global variable part
     * Make sure to make the appropriate changes in exec.c to run part 1 without demandpaging
     */

    // int arrLocal[N];
    // arrLocal[0] = 0;
    // printf(1, "%d\n", arrLocal[0]);

    /*******************
     * Local Part ends here
     */

    pgtprint();
    // for(int i = 0; i < N; i++)
    // {
    //     arrLocal[i] = 0;
    // }
    exit();
}
// int pgtprint()
// {
//   return 0;
// }
