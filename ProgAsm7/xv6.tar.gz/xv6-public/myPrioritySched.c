#include "types.h"
#include "stat.h"
#include "user.h"

void test_func1();
void test_func2();

int main()
{
    printf(1, "Hello, World!\n");
    
    // test_func1();
    test_func2();
    
    exit();
}


void test_func1()
{
    int num = 0;
    // test_func1();
    // test_func2();
    printf(1, "Test Function 1\n");
    for(int i = 1; i < 5; i++)
    {
        // printf(1, "NUM: %d\n", i);
        int pid = fork();
        // printf(1, "NUM: %d\n", i);

        if(pid == 0)
        {
            // printf(1, "Child %d\n", i);
            num = setPriority(i);
            // printf(1, "NUM: %d\n", i);
            
            sleep(1);
            printf(1, "%d Priority: %d\n",getpid(), num);
            break;

            // printf(1, "child end\n");
            
            // exit();
        }
        // wait();
    }
    for(int i = 1; i < 5; i++)
    {
        wait();
    }
}

void test_func2()
{
    printf(1, "Test Function 2\n");
    int num;
    int pid = fork();
    if(pid == 0)
    {
        num = setPriority(-1);
        
        sleep(1);
        printf(1, "%d Priority: %d\n", getpid(), num);
        exit();
    }
    wait();
    exit();
}