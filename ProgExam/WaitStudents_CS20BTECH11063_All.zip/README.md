# OS2 Programming Exam
## Tanmay Garg CS20BTECH11063

Please see the ```Makefile``` for instructions to build and run

- In the program it has been assumed that the value of ```m = 1``` meaning that the lab acts like a file
- The solution uses Readers Writers method to solve for all the parts
- For C part it uses Fair Readers Writers method
- Please give input in ```input.txt``` attached in the folder
- The use of ```sleep``` function to simulate the computation task of usage is done
